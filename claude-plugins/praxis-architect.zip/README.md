# Praxis Architect

Claude plugin for Praxis 0.1.0-alpha.49.1.

## Install

From the Praxis Marketplace (Claude Code, Claude Desktop Code, Cowork):

```
claude plugin marketplace add dfg-inc/praxis-marketplace
claude plugin install praxis-architect@praxis
```

(install `praxis@praxis` instead for all four roles). In the Claude UI: Customize -> Plugins -> Add marketplace -> `dfg-inc/praxis-marketplace`. The Praxis Runtime is installed with the plugin.

This archive is an upload for Claude Desktop Chat, which has no plugin Runtime: install `praxis-runtime.mcpb` first, then upload this ZIP. The light ZIP carries a small hosted subset of the skills; the full ZIP (`praxis-architect-full.zip` in a release) carries every skill and, for BA, the CLI under `tools/`.

## What it needs

- the Praxis Runtime (one shared MCP server; it comes with the marketplace plugin, or as `praxis-runtime.mcpb` for Chat)
- access to the product repository

Jira is not needed: local mode works without any account or token. Jira, Git hosting and similar integrations are optional and configured separately; never paste tokens into chat.

Primary workflow: invoke a role skill and speak naturally. Tools come from the shared Praxis Runtime MCP, not from a per-plugin server. Where the repository or a local runtime is unavailable the tools return `REPOSITORY_UNAVAILABLE` or `LOCAL_RUNTIME_UNAVAILABLE` instead of pretending work ran.
